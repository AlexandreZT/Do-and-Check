Pour obtenir les commandes pour les actions suivantes, dirigez-vous vers : sql/mysql.sql

Votre console mysql ne doit pas contenir de mot de passe.
Vous deverez créer la base de donnée nommée : bdd.
Et ainsi créer les tables suivantes : membres, todolists et taches.

Le reste des commandes ne seront pas nécessaire pour que le projet fonctionne, mais utile pour le développement.