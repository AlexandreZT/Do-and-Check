<?php
session_start();
$mysqli = mysqli_connect("127.0.0.1", "root", "", "bdd");
?>

<!DOCTYPE html>
<html>

<head>
	<title>Do&Check</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<meta charset="utf-8" />
</head>

<body>
	<h1>Do&Check</h1>
	<ul>
		<li><a href="../index.php">Accueil</a></li>
		<li><a href="login.php">Connexion</a></li>
		<li><a href="registration.php">Inscription</a></li>
		<?php
			if (isset($_SESSION['pseudo']))
			{
		?>
		<li><a href="logout.php">Déconnexion </a> </li>
		<?php
			}
		?>
		<li style="float:right"><a class="active" href="help.php">Aide</a></li>
	</ul>

	<p>Une todo list (anglicisme), ou liste de tâches, est un procédé qui se veut simple et efficace pour gérer les tâches d'un projet.</p>
	<p>Ces tâches peuvent être indépendantes ou devoir, au contraire, être accomplies dans un certain ordre. </p>

	<CREDIT>Source by Wikipedia</CREDIT>

	<?php
	if (isset($_SESSION['pseudo'])) // si une variable de session est set =  un utilisateur est connecté
	{
	?>
		<form id="help" action="help.php" method="post">
			<label><b>Supprimer mon compte</b></label>
			<input type="text" name="delete_user" placeholder="Confirmer votre pseudo" value="" />
			<input type="submit" name="Delete_user" value="Je veux supprimer mon compte" />
		</form>
	<?php

		if (isset($_POST['Delete_user'])) {
			if ($_POST['delete_user'] != $_SESSION['pseudo']) {
				echo "<p>Incorret !</p>";
			} else if ($_POST['delete_user'] == $_SESSION['pseudo']) {
				session_destroy(); // détruit la session
				// détruire taches
				$delete_user_todo = $mysqli->query("DELETE FROM taches WHERE membre='$_SESSION[id]'");
				// détruire todolists
				$delete_user_todo = $mysqli->query("DELETE FROM todolists WHERE membre='$_SESSION[id]'");
				// détruit enfin l'utilisateur
				$delete_user = $mysqli->query("DELETE FROM membres WHERE pseudo='$_POST[delete_user]' and id='$_SESSION[id]'");
				header("Refresh:0");
				echo "<p>Votre compte a bien été supprimé avec succès</p>";
			}
		}
	}
	?>

</body>

</html>