<?php
	session_start(); // reprends la session
	session_destroy(); // détruit la session
	// header('location: ../index.php');
?>


<!DOCTYPE html>
<html>

<head>
    <title>Do&Check</title>
    <link rel="stylesheet" type="text/css" href="../css/stylelogs.css">
    <meta charset="utf-8" />
</head>

<body>
    <h1>Do&Check</h1>
    <ul>
        <li><a href="../index.php">Accueil</a></li>
        <li><a href="login.php">Connexion</a></li>
        <li><a href="registration.php">Inscription</a></li>
        <?php
			if (isset($_SESSION['pseudo']))
			{
		?>
		<li><a href="logout.php">Déconnexion </a> </li>
		<?php
			}
		?>
        <li style="float:right"><a class="active" href="help.php">Aide</a></li>
    </ul>
    
	<?php
		$session_status = session_status();
		echo "<p> Au revoir !</p>" ;
        // echo "<p> Status de la sessions :  $session_status </p>"; // _DISABLED = 0 _NONE = 1 _ACTIVE = 2  
    ?>

</body>

</html>